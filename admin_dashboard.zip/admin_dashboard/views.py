from django.shortcuts import render, redirect
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import login as auth_login, logout as auth_logout, authenticate
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.contrib.auth.models import User
from .models import Company, Job, Category
# Create your views here.


def admin_login_view(request):
    if request.method == "POST":
        form=AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user=form.get_user()
            auth_login(request,user)
            return redirect('admin_dashboard')
    else:
        form=AuthenticationForm()
    return render(request, 'admin_login.html',{'form':form})

@login_required(login_url='admin_login')
def admin_dashboard_view(request):
    total_companies=120
    total_users=850
    total_jobs_posted=345
    total_applications=1230

    context={
        'total_companies':total_companies,
        'total_users':total_users,
        'total_jobs_posted':total_jobs_posted,
        'total_applications':total_applications,
    }
    return render(request,'admin_panel.html')


def logout_view(request):
    auth_logout(request)
    return redirect('admin_login')

@login_required(login_url='admin_login')
def post_job_selection_view(request):
    return render(request,'post_job_selection.html')

@login_required(login_url='admin_login')
def register_company_view(request):
    if request.method=='POST':
        company_name=request.POST.get('company_name')
        username=request.POST.get('username')
        password=request.POST.get('password')
        email=request.POST.get('email')
        website=request.POST.get('website')
        location_address=request.POST.get('location_address')

        #basic validation
        if not all([company_name, username, password, email, location_address]):
            messages.error(request,"Please fill in all required fields")
            return render(request,'register_company.html', {
                'company_name':company_name, 'username':username,'email':email, 'website':website, 'location_address':location_address
            })
        
        #for checking username or email is already exists
        if User.objects.filter(username=username).exists():
            messages.error(request, "Username (Company ID) already exists. Please choose a different one")
            return render(request,'register_company.html',{ 'company_name':company_name, 'username':username, 'email':email, 'website':website, 'location_address':location_address })
        
        try:
            company_user=User.objects.create_user(username=username, email=email, password=password)
            company_user.first_name=company_name
            company_user.save()

            #Create the Company profile linked to this user
            company=Company.objects.create(
                name=company_name,
                email=email,
                website=website,
                address=location_address,
                is_approved=True #Admin is registering, so assume approved
            )

            messages.success(request,f"Company '{company_name}' registered successfully! You can now post a job for them.")
            #Redirect to post job form, passing the company ID
            return redirect('post_job_form', company_id=company.id)
        
        except Exception as e:
            messages.error(request, f"An error occured during registration:{e}")
            return render(request, 'register_company.html', {
                'company_name': company_name, 'username':username, 'email':email, 'website':website, 'location_address':location_address
            })
    return render(request,'register_company.html')

@login_required(login_url='admin_login')
def company_login_view(request):
    if request.method=='POST':
        username=request.POST.get('username')
        password=request.POST.get('password')

        user=authenticate(request, username=username, password=password)

        if user is not None:
            try:
                company=Company.objects.get(email=user.email)
                messages.success(request, f"Successfully logged in as '{company.name}'. Now you can post the job")
                return redirect('post_job_form', company_id=company.id)
            except Company.DoesNotExists:
                messages.error(request, "User is not associated with a registered company.")
        else:
            messages.error(request,"Invalid Username or Password.")
        
        return render(request, 'company_login.html',{'username':username})
    return render(request, 'company_login.html')

@login_required(login_url='admin_login')
def post_job_form_view(request, company_id):
    try:
        company=Company.objects.get(id=company_id)
    except Company.DoesNotExists:
        messages.error(request,"Comapny not found.")
        return redirect('post_job_selection')
    
    categories =Category.objects.all().order_by('name')

    if request.method=='POST':
        category_id=request.POST.get('category')
        title=request.POST.get('title')
        vacancy=request.POST.get('vacancy')
        location=request.POST.get('location')
        job_type=request.POST.get('job_type')
        salary=request.POST.get('salary')
        description=request.POST.get(description)

        #basic validation
        if not all([category_id, title, vacancy, location, job_type, description]):
            messages.error(request, "Please fill in all required fields.")
            context={'company':company, 'categories':categories, 'form_data':request.POST}
            return render(request, 'post_job_form.html', context)
        
        try:
            selected_category=Category.objects.get(id=category_id)

        except Category.DoesNotExist:
            messages.error(request, "Invalid category selected.")
            context={'company':company, 'categories':categories, 'form_data':request.POST}
            return render(request, 'post_job_form.html',context)
        
        try:
            job=Job.objects.create(
                company=company,
                category=selected_category,
                title=title,
                vacancy=int(vacancy),
                location=location,
                job_type=job_type,
                description=description,
                status='active',
                salary=salary,
            )
            messages.success(request, f"Job '{job.title}' for '{company.name}'posted successfully!")
            return redirect('admin_dashboard')
        except ValueError:
            messages.error(request, "Invalid number format for Vacancy.")
            context={'company':company, 'categories':categories, 'form_data':request.POST}
            return render(request, 'post_job_form.html', context)
        except Exception as e:
            messages.error(request, f"An error occurred while posting the job: {e}")
            context={'company':company,'categories':categories,'form_data':request.POST}
            return render(request,'post_job_form.html',context)
        
    context={
            'company':company,
            'categories':categories,
        }
    return render(request, 'post_job_form.html',context)



        

