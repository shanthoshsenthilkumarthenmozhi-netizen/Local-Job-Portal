from django.db import models
from django.contrib.auth.models import User
# Create your models here.

#Models for category
class Category(models.Model):
    name=models.CharField(max_length=100, unique=True, verbose_name="Category Name")

    icon_class=models.CharField(max_length=50, blank=True, null=True, verbose_name="Icon Class(Font Awesome)")

    job_count=models.IntegerField(default=0, verbose_name="Number of Jobs")

    class Meta:
        verbose_name_plural="Categories"
        ordering=['name']

    def __str__(self):
        return self.name

#models for companies  
class Company(models.Model):
    name=models.CharField(max_length=255, unique=True, verbose_name="Company Name")
    email=models.EmailField(unique=True, verbose_name="Company Email")
    phone=models.CharField(max_length=20, blank=True, null=True, verbose_name="Phone NUmber")
    website=models.URLField(blank=True, null=True, verbose_name="Website URL")
    address=models.TextField(blank=True, null=True, verbose_name="Address")
    description=models.TextField(blank=True, null=True, verbose_name="Company Description")
    logo=models.FileField(upload_to='company_logos/', blank=True, null=True, verbose_name="Company Logo")
    is_active=models.BooleanField(default=True, verbose_name="Is_Active")

    is_approved=models.BooleanField(default=False, verbose_name="Is Approved by Admin")
    created_at=models.DateTimeField(auto_now_add=True, verbose_name="Created At")
    updated_at=models.DateTimeField(auto_now=True, verbose_name="Last Updated")

    class Meta:
        verbose_name_plural="Companies"
        ordering=['name']

    def __str__(self):
        return self.name
    

#models for job seekers/users
class JobSeeker(models.Model):
    user=models.OneToOneField(User, on_delete=models.CASCADE, related_name='jobseeker_profile',verbose_name="User Account")
    phone=models.CharField(max_length=20, blank=True, null=True, verbose_name="Phone NUmber")
    resume=models.FileField(upload_to='resumes/', blank=True, null=True, verbose_name="Resume File")
    skills=models.TextField(blank=True, null=True, verbose_name="Skills (comma-separated)")
    experience=models.TextField(blank=True, null=True, verbose_name="Experience Details")
    is_active=models.BooleanField(default=True, verbose_name="Is Active")
    created_at=models.DateTimeField(auto_now_add=True, verbose_name="Created At")
    updated_at=models.DateTimeField(auto_now=True, verbose_name="Last Updated")

    class Meta:
        verbose_name_plural= "Job Seekers"
        ordering=['user__first_name','user__last_name'] #Order by user's name

    def __str__(self):
        return f"{self.user.first_name} {self.user.last_name} ({self.user.username})"
    

#model for job posting
class Job(models.Model):
    JOB_TYPE=[
        ('FT', 'Full Time'),
        ('PT', 'Part Time'),
        ('FL', 'Freelance'),
        ('CT', 'Contract'),
        ('IN', 'Internship'),
    ]
    STATUS_CHOICES=[
        ('active', 'Active'),
        ('inactive','Inactive'),
        ('pending', "Pending Approval"),
        ('closed', 'Closed'),
    ]

    company=models.ForeignKey(Company, on_delete=models.CASCADE, related_name='jobs', verbose_name="Company")
    category=models.ForeignKey(Category, on_delete=models.SET_NULL, null=True, blank=True, related_name='jobs', verbose_name="Category")
    title=models.CharField(max_length=255, verbose_name="Job Title/Designation")
    vacancy=models.IntegerField(default=1, verbose_name="Number of Vacancies")
    descritpion=models.TextField(verbose_name="Job Description")
    location=models.CharField(max_length=100, verbose_name="Job Location")
    salary=models.CharField(max_length=100, blank=True, null=True, verbose_name="Salary")
    job_type=models.CharField(max_length=2, choices=JOB_TYPE, default='FT', verbose_name="Job Type")
    status=models.CharField(max_length=10, choices=STATUS_CHOICES, default='pending', verbose_name="Job Status")
    is_featured=models.BooleanField(default=False, verbose_name="Is Featured Job")
    posted_at=models.DateTimeField(auto_now_add=True, verbose_name="Posted At")
    updated_at=models.DateTimeField(auto_now=True, verbose_name="Last Updated")

    class Meta:
        verbose_name_plural="Jobs"
        ordering=['-posted_at'] #order by most recent jobs first

    def __str__(self):
        return f"{self.title} at {self.company.name}"
    
#models for job applications
class Application(models.Model):
    job=models.ForeignKey(Job, on_delete=models.CASCADE, related_name='application', verbose_name="Job Applied For")
    job_seeker=models.ForeignKey(JobSeeker, on_delete=models.CASCADE, related_name='applications', verbose_name="Applicant")

    #status of the applocation
    APPLICATION_STATUS_CHOICES=[
        ('pending', 'Pending'),
        ('reviewed', 'Reviewed'),
        ('interview', 'Interview Scheduled'),
        ('hired', 'Hired'),
        ('rejected','Rejected'),
    ]
    status=models.CharField(max_length=20, choices=APPLICATION_STATUS_CHOICES, default='pending', verbose_name="Application Status")
    applied_at=models.DateTimeField(auto_now_add=True, verbose_name="Applied At")
    updated_at=models.DateTimeField(auto_now=True, verbose_name="Last Updated")

    class Meta:
        verbose_name_plural="Application"
        unique_together=('job','job_seeker') #job seeker can only apply once per job
        ordering=['-applied_at'] #order by most recent applications

    def __str__(self):
        return f"Application for {self.job.title} by {self.job_seeker.user.username}"







    


