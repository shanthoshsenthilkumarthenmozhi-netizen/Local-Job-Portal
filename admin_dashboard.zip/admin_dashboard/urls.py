from django.urls import path
from admin_dashboard import views

urlpatterns= [
    path('admin_login/',views.admin_login_view,name='admin_login'),
    path('admin_dashboard/',views.admin_dashboard_view, name='admin_dashboard'),
    path('admin-logout',views.logout_view, name='logout'),

    path('post-job-selection/', views.post_job_selection_view, name='post_job_selection'),
    path('register-company/', views.register_company_view, name='register_company'),
    path('company-login', views.company_login_view, name='company_login'),
    path('post-job-form/<int:company_id>/', views.post_job_form_view, name='post_job_form',)

]