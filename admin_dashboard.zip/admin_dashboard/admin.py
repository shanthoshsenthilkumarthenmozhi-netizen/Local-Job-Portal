
from django.contrib import admin
from admin_dashboard.models import Category, Company, Job, JobSeeker, Application

# Register your models here.

@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ('name', 'job_count', 'icon_class')
    search_fields = ('name',)
    # Make job_count read-only in admin as it's updated by signals
    readonly_fields = ('job_count',)

@admin.register(Company)
class CompanyAdmin(admin.ModelAdmin):
    list_display = ('name', 'email', 'phone', 'is_approved', 'is_active', 'created_at')
    list_filter = ('is_approved', 'is_active')
    search_fields = ('name', 'email', 'address')
    date_hierarchy = 'created_at' # Adds a date-based drilldown navigation

@admin.register(Job)
class JobAdmin(admin.ModelAdmin):
    list_display = ('title', 'company', 'category', 'vacancy', 'location', 'job_type', 'status', 'posted_at')
    list_filter = ('job_type', 'status', 'category', 'company')
    search_fields = ('title', 'description', 'location', 'company__name')
    raw_id_fields = ('company', 'category') # Use raw_id_fields for FKs if many objects
    date_hierarchy = 'posted_at'
    actions = ['make_active', 'make_inactive', 'make_pending', 'make_closed']

    def make_active(self, request, queryset):
        queryset.update(status='active')
        self.message_user(request, "Selected jobs marked as active.")
    make_active.short_description = "Mark selected jobs as Active"

    def make_inactive(self, request, queryset):
        queryset.update(status='inactive')
        self.message_user(request, "Selected jobs marked as inactive.")
    make_inactive.short_description = "Mark selected jobs as Inactive"

    def make_pending(self, request, queryset):
        queryset.update(status='pending')
        self.message_user(request, "Selected jobs marked as pending approval.")
    make_pending.short_description = "Mark selected jobs as Pending Approval"

    def make_closed(self, request, queryset):
        queryset.update(status='closed')
        self.message_user(request, "Selected jobs marked as closed.")
    make_closed.short_description = "Mark selected jobs as Closed"


@admin.register(JobSeeker)
class JobSeekerAdmin(admin.ModelAdmin):
    list_display = ('user_username', 'user_email', 'phone', 'is_active', 'created_at')
    list_filter = ('is_active',)
    search_fields = ('user__username', 'user__email', 'user__first_name', 'user__last_name', 'skills')
    raw_id_fields = ('user',)
    date_hierarchy = 'created_at'

    def user_username(self, obj):
        return obj.user.username
    user_username.short_description = 'Username'

    def user_email(self, obj):
        return obj.user.email
    user_email.short_description = 'Email'

@admin.register(Application)
class ApplicationAdmin(admin.ModelAdmin):
    list_display = ('job', 'job_seeker', 'status', 'applied_at')
    list_filter = ('status', 'job', 'job_seeker')
    search_fields = ('job__title', 'job_seeker__user__username', 'cover_letter')
    raw_id_fields = ('job', 'job_seeker')
    date_hierarchy = 'applied_at'